Danny Liche Web Makers website

Open index.html to preview the site.
The service and portfolio cards now place images beside their paragraphs.
The top hero/logo image is maintained.
All image paths in index.html point to the included assets folder.
